﻿from __future__ import annotations
from typing import Any, Dict, Iterable
import unicodedata
from src.ocr.base import OCRResult

class PostProcessor:
    def __init__(self) -> None:
        pass

    def process(self, text_results: Iterable[Any]) -> Dict[str, Any]:
        """Process OCR results to improve accuracy and extract metadata."""
        processed_results: Dict[str, Any] = {
            "text": [],
            "metadata": {
                "document_type": None,
                "languages_detected": set(),
                "confidence": 0.0,
            },
        }

        total_conf = 0.0
        count = 0

        for result in (text_results or []):
            if isinstance(result, str):
                text = result
                conf = 0.0
                lang = self._guess_lang(text)
            elif isinstance(result, OCRResult):
                text = (result.text or "")
                conf = float(result.confidence or 0.0)
                lang = result.lang or self._guess_lang(text)
            elif isinstance(result, dict):
                text = str(result.get("text") or "")
                conf = float(result.get("confidence") or 0.0)
                lang = result.get("lang") or self._guess_lang(text)
            else:
                continue

            text = text.strip()
            if not text:
                continue

            processed_results["text"].append(text)
            if lang:
                processed_results["metadata"]["languages_detected"].add(lang)
            if conf >= 0:
                total_conf += conf
                count += 1

        processed_results["metadata"]["confidence"] = (total_conf / count) if count else 0.0

        # Simple document-type heuristic (accent-agnostic)
        txt_raw = " ".join(processed_results["text"])
        txt = txt_raw.lower()
        txt_no_acc = "".join(
            ch for ch in unicodedata.normalize("NFD", txt) if unicodedata.category(ch) != "Mn"
        )

        if ("certificat" in txt_no_acc) or ("شهادة" in txt):
            processed_results["metadata"]["document_type"] = "certificate"
        elif ("autorisation" in txt_no_acc) or ("رخصة" in txt):
            processed_results["metadata"]["document_type"] = "authorization"
        elif ("declaration" in txt_no_acc) or ("declar" in txt_no_acc) or ("تصريح" in txt):
            processed_results["metadata"]["document_type"] = "declaration"

        # Make languages JSON-friendly
        processed_results["metadata"]["languages_detected"] = sorted(
            processed_results["metadata"]["languages_detected"]
        )
        return processed_results

    @staticmethod
    def _guess_lang(text: str) -> str | None:
        # Arabic block range
        if any("\u0600" <= ch <= "\u06FF" for ch in text):
            return "arabic"
        # crude Latin detection good enough for FR here
        if any("a" <= ch.lower() <= "z" for ch in text):
            return "french"
        return None
