﻿from typing import Dict, Any, Tuple, List
import json
import re
import statistics
from pathlib import Path
import cv2
import numpy as np
from src.postprocessing.validators import normalize_field

def _build_tess_config(rel: Dict[str, Any]) -> str:
    cfg: List[str] = []
    if (psm := rel.get('psm')) is not None: cfg += ['--psm', str(psm)]
    if (oem := rel.get('oem')) is not None: cfg += ['--oem', str(oem)]
    if (dpi := rel.get('dpi')) is not None: cfg += ['-c', f'user_defined_dpi={int(dpi)}']
    if rel.get('preserve_spaces'): cfg += ['-c', 'preserve_interword_spaces=1']
    if (wl := rel.get('whitelist')): cfg += ['-c', f'tessedit_char_whitelist={wl}']
    if (bl := rel.get('blacklist')): cfg += ['-c', f'tessedit_char_blacklist={bl}']
    
    # Special handling for Arabic to prevent Latin character confusion
    if rel.get('lang') == 'arabic':
        cfg += ['--oem', '1',  # Use LSTM mode
                '-c', 'preserve_interword_spaces=1',
                '-c', 'tessedit_char_blacklist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz']
    return " ".join(cfg)

def _apply_scale(img: np.ndarray, rel: Dict[str, Any]) -> np.ndarray:
    s = rel.get('scale')
    try:
        s = float(s) if s is not None else 1.0
    except Exception:
        s = 1.0
    if s and s != 1.0:
        return cv2.resize(img, dsize=None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
    return img

def _result_to_dict(r: Any) -> Dict[str, Any]:
    if hasattr(r, 'to_dict'):
        return r.to_dict()
    if hasattr(r, '__dict__') and hasattr(r, 'text'):
        bbox = getattr(r, 'bounding_box', (0,0,1,1))
        x, y, w, h = bbox if isinstance(bbox, (list, tuple)) and len(bbox)==4 else (0,0,1,1)
        return {
            "text": getattr(r, "text", ""),
            "confidence": float(getattr(r, "confidence", 0.0)),
            "bbox": [int(x), int(y), int(w), int(h)],
            "language": getattr(r, "language", ""),
            "page_number": int(getattr(r, "page_number", 1)),
        }
    if isinstance(r, dict):
        return r
    return {"text": str(r)}

class TemplateExtractor:
    """Crop ROIs from a known template and run the appropriate OCR engine per ROI."""
    def __init__(self, templates_path: str = 'assets/templates/morocco_templates.json'):
        self.templates_path = Path(templates_path)
        with open(self.templates_path, 'r', encoding='utf-8-sig') as f:
            self.templates: Dict[str, Any] = json.load(f)

    def _abs_box(self, H: int, W: int, rel: Dict[str, float]) -> Tuple[int,int,int,int]:
        x = int(rel['x'] * W); y = int(rel['y'] * H)
        w = int(rel['w'] * W); h = int(rel['h'] * H)
        x = max(0, min(x, W-1)); y = max(0, min(y, H-1))
        w = max(1, min(w, W-x)); h = max(1, min(h, H-y))
        return x, y, w, h

    def _run_engine(self, engine: Any, crop: np.ndarray, config: str):
        try:
            return engine.process_document(crop, config=config)
        except TypeError:
            try:
                return engine.process(crop, config=config)
            except TypeError:
                try:
                    return engine.process_document(crop)
                except TypeError:
                    return engine.process(crop)

    def run(self, image: np.ndarray, template_key: str, engines: Dict[str, Any]) -> Dict[str, Any]:
        if template_key not in self.templates:
            raise KeyError(f"Unknown template '{template_key}' in {self.templates_path}")
        tpl = self.templates[template_key]
        H, W = image.shape[:2]
        out: Dict[str, Any] = {'fields': {}, 'raw': {}, 'metadata': {}}

        for section, fields in tpl['regions'].items():
            for name, rel in fields.items():
                x, y, w, h = self._abs_box(H, W, rel)
                crop = image[y:y+h, x:x+w]
                crop = _apply_scale(crop, rel)
                config = _build_tess_config(rel)

                lang_key = rel.get('lang')
                if not lang_key:
                    is_ar = (section == 'title' and name == 'ar') or any('\u0600' <= ch <= '\u06FF' for ch in name)
                    lang_key = 'arabic' if is_ar else 'french'

                engine = engines.get(lang_key) or engines.get('hybrid')
                if engine is None:
                    raise RuntimeError(f"No OCR engine available for {lang_key}")

                results = self._run_engine(engine, crop, config)

                best_text, best_conf, best_area = '', 0.0, 1
                safe_raw: List[Dict[str, Any]] = []
                for r in results:
                    rd = _result_to_dict(r)
                    safe_raw.append(rd)
                    text = rd.get('text', '')
                    conf = float(rd.get('confidence', 0.0))
                    bx = rd.get('bbox', (0,0,1,1))
                    x0, y0, w0, h0 = bx if isinstance(bx, (list, tuple)) and len(bx)==4 else (0,0,1,1)
                    area = max(1, int(w0) * int(h0))
                    if conf*area > best_conf*best_area:
                        best_text, best_conf, best_area = text, conf, area

                # collect per-token text + conf from both safe_raw and results
                def _iter_text_conf(items):
                    for rd in items or []:
                        if isinstance(rd, dict):
                            t = str(rd.get("text", "") or "")
                            c = rd.get("confidence", rd.get("conf", -1))
                        else:
                            t = str(getattr(rd, "text", "") or "")
                            c = getattr(rd, "confidence", -1)
                        try:
                            c = float(c)
                        except Exception:
                            c = -1.0
                        yield t, c

                texts, token_confs, digit_confs = [], [], []
                for t, c in _iter_text_conf(safe_raw):
                    if t:
                        texts.append(t)
                        if c >= 0:
                            token_confs.append(c)
                            if any(ch.isdigit() for ch in t) or "/" in t or "-" in t:
                                digit_confs.append(c)

                # if ROI tokens lacked digit-ish parts, also scan `results` as a fallback
                if not digit_confs:
                    for t, c in _iter_text_conf(results):
                        if t and c >= 0 and (any(ch.isdigit() for ch in t) or "/" in t or "-"):
                            digit_confs.append(c)

                base_conf = statistics.fmean(token_confs) if token_confs else 0.0
                digit_conf = statistics.median(digit_confs) if digit_confs else None

                # --- Build line-level candidates (text only); use separate *score* confs ---
                joined = " ".join(texts).strip()
                digits_only = re.sub(r"[^\d/-]+", "", joined)

                score_candidates = []
                if joined:
                    score_candidates.append(("joined", joined, base_conf))
                if digits_only:
                    # tiny preference for digits at scoring-time ONLY
                    score_candidates.append(("digits", digits_only, (digit_conf if digit_conf is not None else base_conf) + 0.1))
                if best_text:
                    score_candidates.append(("token", best_text, base_conf))

                chosen_label, chosen_text, chosen_score = "token", best_text, base_conf
                chosen_norm = {"type": "text", "value": "", "valid": False}

                for label, txt, sc in score_candidates:
                    nrm = normalize_field(f"{section}.{name}", txt)
                    # prefer valid, then higher score conf, then longer text
                    score = (1 if nrm.get("valid") else 0, sc, len(txt))
                    if score > (1 if chosen_norm.get("valid") else 0, chosen_score, len(chosen_text or "")):
                        chosen_label, chosen_text, chosen_score, chosen_norm = label, txt, sc, nrm

                # Final values to store:
                best_text = chosen_text
                norm = chosen_norm

                # For *confidence*, use the MEDIAN of digit-ish tokens when this is the receipt number;
                # otherwise use the base token average.
                field_key = f"{section}.{name}"
                if (name == "receipt_no" or field_key.endswith(".receipt_no")) and digit_conf is not None:
                    best_conf = float(digit_conf)
                else:
                    best_conf = float(base_conf)

                out['fields'][f"{section}.{name}"] = {
                    'value': best_text,
                    'norm': norm.get('value'),
                    'valid': bool(norm.get('valid')),
                    'type': norm.get('type'),
                    'conf': best_conf,
                    'lang': lang_key,
                    'bbox': [x, y, w, h],
                }
                out['raw'].setdefault(lang_key, []).extend(safe_raw)

        out['metadata'] = {
            'template_name': tpl.get('name'),
            'template_name_ar': tpl.get('name_ar'),
            'template_version': tpl.get('template_version', '1.0'),
            'required_fields': tpl.get('required_fields', []),
        }
        return out


