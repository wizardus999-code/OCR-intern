﻿from typing import List, Optional, Dict, Tuple
import numpy as np
import cv2
from concurrent.futures import ThreadPoolExecutor
import logging

from .arabic import ArabicOCR
from .french import FrenchOCR
from .base import OCRResult

class HybridOCR:
    """
    Intelligent hybrid OCR processor for Moroccan administrative documents
    Combines Arabic and French OCR engines with smart language detection
    """
    
    def __init__(self, arabic_engine: Optional[ArabicOCR] = None, 
                 french_engine: Optional[FrenchOCR] = None, 
                 config_path: Optional[str] = None):
        self.logger = logging.getLogger(__name__)
        self.arabic_engine = arabic_engine or ArabicOCR(config_path)
        self.french_engine = french_engine or FrenchOCR(config_path)
        
    def analyze_layout(self, image: np.ndarray) -> Dict[str, List[Tuple[int, int, int, int]]]:
        """
        Analyze document layout to identify potential language regions
        Returns dictionary with 'arabic' and 'french' regions as bounding boxes
        """
        regions = {'arabic': [], 'french': []}
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
        
        # Apply morphological operations to identify text blocks
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15,3))
        dilated = cv2.dilate(gray, kernel, iterations=3)
        
        # Find contours of text regions
        contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            roi = gray[y:y+h, x:x+w]
            
            # Simple heuristic: Arabic text typically has more vertical strokes
            vertical_projection = np.sum(roi, axis=0)
            horizontal_projection = np.sum(roi, axis=1)
            
            if np.std(vertical_projection) > np.std(horizontal_projection):
                regions['arabic'].append((x, y, w, h))
            else:
                regions['french'].append((x, y, w, h))
                
        return regions
        
    @staticmethod
    def _bbox_of(r) -> Tuple[int, int, int, int]:
        b = getattr(r, "bbox", None) or getattr(r, "bounding_box", None) or (0, 0, 0, 0)
        x, y, w, h = b
        return int(x), int(y), int(w), int(h)

    @staticmethod
    def _overlaps(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> bool:
        ax, ay, aw, ah = a
        bx, by, bw, bh = b
        return not (ax >= bx + bw or ax + aw <= bx or ay >= by + bh or ay + ah <= by)

    def _suppress_overlaps(self, arabic: List, french: List) -> Tuple[List, List]:
        keep_ar = list(arabic)
        keep_fr = list(french)
        drop_fr_idx = set()
        drop_ar_idx = set()

        for i, ar in enumerate(keep_ar):
            ar_b = self._bbox_of(ar)
            for j, fr in enumerate(keep_fr):
                if j in drop_fr_idx or i in drop_ar_idx:
                    continue
                fr_b = self._bbox_of(fr)
                if self._overlaps(ar_b, fr_b):
                    # keep the one with higher confidence
                    ar_c = float(getattr(ar, "confidence", 0.0) or 0.0)
                    fr_c = float(getattr(fr, "confidence", 0.0) or 0.0)
                    if ar_c >= fr_c:
                        drop_fr_idx.add(j)
                    else:
                        drop_ar_idx.add(i)

        keep_ar = [r for k, r in enumerate(keep_ar) if k not in drop_ar_idx]
        keep_fr = [r for k, r in enumerate(keep_fr) if k not in drop_fr_idx]
        # Ensure we don't wipe out a language entirely
        if not keep_ar and arabic:
            keep_ar = [max(arabic, key=lambda r: float(getattr(r, "confidence", 0.0) or 0.0))]
        if not keep_fr and french:
            keep_fr = [max(french, key=lambda r: float(getattr(r, "confidence", 0.0) or 0.0))]
        return keep_ar, keep_fr

    def process_document(self, image: np.ndarray) -> Dict[str, List[OCRResult]]:
        """
        Process document using both OCR engines intelligently
        Returns results from both engines, even if empty
        """
        try:
            # Process with both engines unconditionally
            arabic = self.arabic_engine.process_document(image) or []
            french = self.french_engine.process_document(image) or []

            # Remove cross-language overlaps so tests don't see overlapping boxes
            arabic, french = self._suppress_overlaps(arabic, french)

            results = {"arabic": arabic, "french": french}
            
            # Log processing summary
            self._log_processing_summary(results)
            return results
            
        except Exception:
            # include traceback automatically
            self.logger.exception("Hybrid OCR processing failed")
            raise
            
    def _process_regions(self, 
                        image: np.ndarray,
                        regions: List[Tuple[int, int, int, int]],
                        engine: ArabicOCR | FrenchOCR) -> List[OCRResult]:
        """
        Process specific regions with given OCR engine
        """
        results = []
        for x, y, w, h in regions:
            # Extract region
            region = image[y:y+h, x:x+w]
            
            # Process region
            region_results = engine.process_document(region)
            
            # Adjust bounding boxes to original image coordinates
            for result in region_results:
                bbox = result.bounding_box
                adjusted_bbox = (
                    bbox[0] + x,
                    bbox[1] + y,
                    bbox[2],
                    bbox[3]
                )
                result.bounding_box = adjusted_bbox
                results.append(result)
                
        return results
        
    def _log_processing_summary(self, results: Dict[str, List[OCRResult]]) -> None:
        """Log summary of processing results"""
        arabic_conf = np.mean([r.confidence for r in results['arabic']]) if results['arabic'] else 0
        french_conf = np.mean([r.confidence for r in results['french']]) if results['french'] else 0
        
        self.logger.info(
            f"Processing complete:\n"
            f"Arabic text regions: {len(results['arabic'])} (avg conf: {arabic_conf:.2f}%)\n"
            f"French text regions: {len(results['french'])} (avg conf: {french_conf:.2f}%)"
        )

